# -*- coding: utf-8 -*-
"""Super timeline all the things (Plaso Langar Að Safna Öllu).

log2timeline is a tool designed to extract timestamps from various files found
on a typical computer system(s) and aggregate them. Plaso is the Python rewrite
of log2timeline.
"""

__version__ = '20221126'
