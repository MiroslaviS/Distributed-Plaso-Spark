import json

from looter import nonsig_parsers

if __name__ == "__main__":
    json.load("/mnt/c/skola/prototypes/")