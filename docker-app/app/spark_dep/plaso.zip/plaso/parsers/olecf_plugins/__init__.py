# -*- coding: utf-8 -*-
"""This file contains an import statement for each OLECF plugin."""

from plaso.parsers.olecf_plugins import automatic_destinations
from plaso.parsers.olecf_plugins import default
from plaso.parsers.olecf_plugins import summary
