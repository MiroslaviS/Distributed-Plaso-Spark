# -*- coding: utf-8 -*-
"""Preprocessor."""

from plaso.preprocessors import generic
from plaso.preprocessors import linux
from plaso.preprocessors import macos
from plaso.preprocessors import windows
