# -*- coding: utf-8 -*-
"""This file imports Python modules that register analyzers."""

from plaso.analyzers import hashing_analyzer
from plaso.analyzers import yara_analyzer
